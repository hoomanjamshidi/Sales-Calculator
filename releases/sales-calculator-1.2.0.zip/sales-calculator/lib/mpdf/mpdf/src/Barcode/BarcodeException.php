<?php

namespace SalesCalculatorVendor\Mpdf\Barcode;

class BarcodeException extends \SalesCalculatorVendor\Mpdf\MpdfException
{
}
