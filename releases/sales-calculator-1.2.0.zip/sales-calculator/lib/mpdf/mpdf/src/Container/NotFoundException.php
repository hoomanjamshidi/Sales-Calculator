<?php

namespace SalesCalculatorVendor\Mpdf\Container;

class NotFoundException extends \SalesCalculatorVendor\Mpdf\MpdfException
{
}
