<?php

namespace SalesCalculatorVendor\Mpdf\Exception;

class AssetFetchingException extends \SalesCalculatorVendor\Mpdf\MpdfException
{
}
