<?php

namespace SalesCalculatorVendor\Mpdf\Exception;

class FontException extends \SalesCalculatorVendor\Mpdf\MpdfException
{
}
