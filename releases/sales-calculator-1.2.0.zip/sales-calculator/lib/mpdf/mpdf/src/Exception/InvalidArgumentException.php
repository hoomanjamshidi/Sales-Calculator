<?php

namespace SalesCalculatorVendor\Mpdf\Exception;

class InvalidArgumentException extends \SalesCalculatorVendor\Mpdf\MpdfException
{
}
