<?php

namespace SalesCalculatorVendor\Mpdf\File;

class LocalContentLoader implements \SalesCalculatorVendor\Mpdf\File\LocalContentLoaderInterface
{
    public function load($path)
    {
        return file_get_contents($path);
    }
}
