<?php

namespace SalesCalculatorVendor\Mpdf\Http;

use SalesCalculatorVendor\Psr\Http\Message\RequestInterface;
interface ClientInterface
{
    public function sendRequest(RequestInterface $request);
}
