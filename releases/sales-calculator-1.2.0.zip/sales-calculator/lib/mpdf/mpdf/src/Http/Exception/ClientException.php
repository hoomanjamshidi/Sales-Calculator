<?php

namespace SalesCalculatorVendor\Mpdf\Http\Exception;

class ClientException extends \SalesCalculatorVendor\Mpdf\MpdfException
{
}
