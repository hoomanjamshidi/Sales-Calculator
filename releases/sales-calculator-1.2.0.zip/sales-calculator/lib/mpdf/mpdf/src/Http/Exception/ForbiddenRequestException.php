<?php

namespace SalesCalculatorVendor\Mpdf\Http\Exception;

class ForbiddenRequestException extends \SalesCalculatorVendor\Mpdf\MpdfException
{
}
