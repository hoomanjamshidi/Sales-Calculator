<?php

namespace SalesCalculatorVendor\Mpdf\Http\Exception;

class NetworkException extends \SalesCalculatorVendor\Mpdf\MpdfException
{
}
