<?php

namespace SalesCalculatorVendor\Mpdf\Http\Exception;

class RequestException extends \SalesCalculatorVendor\Mpdf\MpdfException
{
}
