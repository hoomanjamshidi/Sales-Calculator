<?php

namespace SalesCalculatorVendor\Mpdf;

class MpdfException extends \ErrorException
{
}
