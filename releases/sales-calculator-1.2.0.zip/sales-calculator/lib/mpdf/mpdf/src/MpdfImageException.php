<?php

namespace SalesCalculatorVendor\Mpdf;

class MpdfImageException extends \SalesCalculatorVendor\Mpdf\MpdfException
{
}
