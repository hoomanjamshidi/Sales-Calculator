<?php

namespace SalesCalculatorVendor\Mpdf;

use SalesCalculatorVendor\Mpdf\Color\ColorConverter;
use SalesCalculatorVendor\Mpdf\Color\ColorModeConverter;
use SalesCalculatorVendor\Mpdf\Color\ColorSpaceRestrictor;
use SalesCalculatorVendor\Mpdf\Css\BorderMerger;
use SalesCalculatorVendor\Mpdf\Css\CssMerger;
use SalesCalculatorVendor\Mpdf\Css\CssParser;
use SalesCalculatorVendor\Mpdf\Css\InlinePropertyConverter;
use SalesCalculatorVendor\Mpdf\Css\InlineStyleParser;
use SalesCalculatorVendor\Mpdf\Css\NormalizeProperties;
use SalesCalculatorVendor\Mpdf\Css\SelectorParser;
use SalesCalculatorVendor\Mpdf\Css\ShadowParser;
use SalesCalculatorVendor\Mpdf\File\LocalContentLoader;
use SalesCalculatorVendor\Mpdf\Fonts\FontCache;
use SalesCalculatorVendor\Mpdf\Fonts\FontFileFinder;
use SalesCalculatorVendor\Mpdf\Http\CurlHttpClient;
use SalesCalculatorVendor\Mpdf\Http\SocketHttpClient;
use SalesCalculatorVendor\Mpdf\Image\ImageProcessor;
use SalesCalculatorVendor\Mpdf\Pdf\Protection;
use SalesCalculatorVendor\Mpdf\Pdf\Protection\UniqidGenerator;
use SalesCalculatorVendor\Mpdf\Writer\BaseWriter;
use SalesCalculatorVendor\Mpdf\Writer\BackgroundWriter;
use SalesCalculatorVendor\Mpdf\Writer\ColorWriter;
use SalesCalculatorVendor\Mpdf\Writer\BookmarkWriter;
use SalesCalculatorVendor\Mpdf\Writer\FontWriter;
use SalesCalculatorVendor\Mpdf\Writer\FormWriter;
use SalesCalculatorVendor\Mpdf\Writer\ImageWriter;
use SalesCalculatorVendor\Mpdf\Writer\JavaScriptWriter;
use SalesCalculatorVendor\Mpdf\Writer\MetadataWriter;
use SalesCalculatorVendor\Mpdf\Writer\OptionalContentWriter;
use SalesCalculatorVendor\Mpdf\Writer\PageWriter;
use SalesCalculatorVendor\Mpdf\Writer\ResourceWriter;
use SalesCalculatorVendor\Psr\Log\LoggerInterface;
class ServiceFactory
{
    /**
     * @var \Mpdf\Container\ContainerInterface|null
     */
    private $container;
    public function __construct($container = null)
    {
        $this->container = $container;
    }
    public function getServices(Mpdf $mpdf, LoggerInterface $logger, $config, $languageToFont, $scriptToLanguage, $fontDescriptor, $bmp, $directWrite, $wmf)
    {
        $sizeConverter = new SizeConverter($mpdf->dpi, $mpdf->default_font_size, $mpdf, $logger);
        $colorModeConverter = new ColorModeConverter();
        $colorSpaceRestrictor = new ColorSpaceRestrictor($mpdf, $colorModeConverter);
        $colorConverter = new ColorConverter($mpdf, $colorModeConverter, $colorSpaceRestrictor);
        $tableOfContents = new TableOfContents($mpdf, $sizeConverter);
        $cacheBasePath = $config['tempDir'] . '/mpdf';
        $cache = new Cache($cacheBasePath, $config['cacheCleanupInterval']);
        $fontCache = new FontCache(new Cache($cacheBasePath . '/ttfontdata', $config['cacheCleanupInterval']));
        $fontFileFinder = new FontFileFinder($config['fontDir']);
        if ($this->container && $this->container->has('httpClient')) {
            $httpClient = $this->container->get('httpClient');
        } elseif (\function_exists('curl_init')) {
            $httpClient = new CurlHttpClient($mpdf, $logger);
        } else {
            $httpClient = new SocketHttpClient($logger);
        }
        $localContentLoader = $this->container && $this->container->has('localContentLoader') ? $this->container->get('localContentLoader') : new LocalContentLoader();
        $assetFetcher = $this->container && $this->container->has('assetFetcher') ? $this->container->get('assetFetcher') : new AssetFetcher($mpdf, $localContentLoader, $httpClient, $logger);
        $normalizeProperties = new NormalizeProperties($mpdf, $sizeConverter, $colorConverter);
        $selectorParser = new SelectorParser($mpdf);
        $inlineStyleParser = new InlineStyleParser($normalizeProperties);
        $inlinePropertyConverter = new InlinePropertyConverter($colorConverter);
        $borderMerger = new BorderMerger();
        $cssParser = new CssParser($mpdf, $cache, $sizeConverter, $colorConverter, $assetFetcher);
        $cssMerger = new CssMerger($mpdf, $normalizeProperties, $inlineStyleParser, $selectorParser, $inlinePropertyConverter, $colorConverter, $borderMerger);
        $cssManager = new CssManager($cssParser, $cssMerger);
        $otl = new Otl($mpdf, $fontCache);
        $protection = new Protection(new UniqidGenerator());
        $writer = new BaseWriter($mpdf, $protection);
        $gradient = new Gradient($mpdf, $sizeConverter, $colorConverter, $writer);
        $formWriter = new FormWriter($mpdf, $writer);
        $form = new Form($mpdf, $otl, $colorConverter, $writer, $formWriter);
        $hyphenator = new Hyphenator($mpdf);
        $imageProcessor = new ImageProcessor($mpdf, $otl, $cssManager, $sizeConverter, $colorConverter, $colorModeConverter, $cache, $languageToFont, $scriptToLanguage, $assetFetcher, $logger);
        $tag = new Tag($mpdf, $cache, $cssManager, $form, $otl, $tableOfContents, $sizeConverter, $colorConverter, $imageProcessor, $languageToFont);
        $fontWriter = new FontWriter($mpdf, $writer, $fontCache, $fontDescriptor);
        $metadataWriter = new MetadataWriter($mpdf, $writer, $form, $protection, $logger);
        $imageWriter = new ImageWriter($mpdf, $writer);
        $pageWriter = new PageWriter($mpdf, $form, $writer, $metadataWriter);
        $bookmarkWriter = new BookmarkWriter($mpdf, $writer);
        $optionalContentWriter = new OptionalContentWriter($mpdf, $writer);
        $colorWriter = new ColorWriter($mpdf, $writer);
        $backgroundWriter = new BackgroundWriter($mpdf, $writer);
        $javaScriptWriter = new JavaScriptWriter($mpdf, $writer);
        $resourceWriter = new ResourceWriter($mpdf, $writer, $colorWriter, $fontWriter, $imageWriter, $formWriter, $optionalContentWriter, $backgroundWriter, $bookmarkWriter, $metadataWriter, $javaScriptWriter, $logger);
        return ['otl' => $otl, 'bmp' => $bmp, 'cache' => $cache, 'cssManager' => $cssManager, 'directWrite' => $directWrite, 'fontCache' => $fontCache, 'fontFileFinder' => $fontFileFinder, 'form' => $form, 'gradient' => $gradient, 'tableOfContents' => $tableOfContents, 'tag' => $tag, 'wmf' => $wmf, 'sizeConverter' => $sizeConverter, 'colorConverter' => $colorConverter, 'hyphenator' => $hyphenator, 'localContentLoader' => $localContentLoader, 'httpClient' => $httpClient, 'assetFetcher' => $assetFetcher, 'imageProcessor' => $imageProcessor, 'protection' => $protection, 'languageToFont' => $languageToFont, 'scriptToLanguage' => $scriptToLanguage, 'writer' => $writer, 'fontWriter' => $fontWriter, 'metadataWriter' => $metadataWriter, 'imageWriter' => $imageWriter, 'formWriter' => $formWriter, 'pageWriter' => $pageWriter, 'bookmarkWriter' => $bookmarkWriter, 'optionalContentWriter' => $optionalContentWriter, 'colorWriter' => $colorWriter, 'backgroundWriter' => $backgroundWriter, 'javaScriptWriter' => $javaScriptWriter, 'resourceWriter' => $resourceWriter];
    }
    public function getServiceIds()
    {
        return ['otl', 'bmp', 'cache', 'cssManager', 'directWrite', 'fontCache', 'fontFileFinder', 'form', 'gradient', 'tableOfContents', 'tag', 'wmf', 'sizeConverter', 'colorConverter', 'hyphenator', 'localContentLoader', 'httpClient', 'assetFetcher', 'imageProcessor', 'protection', 'languageToFont', 'scriptToLanguage', 'writer', 'fontWriter', 'metadataWriter', 'imageWriter', 'formWriter', 'pageWriter', 'bookmarkWriter', 'optionalContentWriter', 'colorWriter', 'backgroundWriter', 'javaScriptWriter', 'resourceWriter'];
    }
}
