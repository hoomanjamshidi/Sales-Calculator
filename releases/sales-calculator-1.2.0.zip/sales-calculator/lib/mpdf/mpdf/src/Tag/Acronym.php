<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Acronym extends InlineTag
{
}
