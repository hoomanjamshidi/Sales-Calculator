<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Address extends BlockTag
{
}
