<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Aside extends BlockTag
{
}
