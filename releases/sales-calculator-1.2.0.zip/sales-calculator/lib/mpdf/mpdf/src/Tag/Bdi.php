<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Bdi extends InlineTag
{
}
