<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Bdo extends InlineTag
{
}
