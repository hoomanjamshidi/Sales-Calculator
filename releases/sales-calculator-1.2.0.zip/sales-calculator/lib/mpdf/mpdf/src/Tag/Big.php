<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Big extends InlineTag
{
}
