<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class BlockQuote extends BlockTag
{
}
