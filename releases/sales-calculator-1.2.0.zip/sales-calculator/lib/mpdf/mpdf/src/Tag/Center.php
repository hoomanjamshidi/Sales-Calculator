<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Center extends BlockTag
{
}
