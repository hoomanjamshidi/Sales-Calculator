<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Cite extends InlineTag
{
}
