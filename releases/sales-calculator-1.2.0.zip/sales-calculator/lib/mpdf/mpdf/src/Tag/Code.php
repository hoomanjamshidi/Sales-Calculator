<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Code extends InlineTag
{
}
