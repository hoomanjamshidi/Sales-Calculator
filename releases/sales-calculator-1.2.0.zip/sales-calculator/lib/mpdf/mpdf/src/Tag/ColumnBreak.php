<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class ColumnBreak extends NewColumn
{
}
