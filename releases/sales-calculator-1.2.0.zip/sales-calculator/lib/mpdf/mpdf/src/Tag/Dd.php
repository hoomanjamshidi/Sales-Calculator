<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Dd extends BlockTag
{
}
