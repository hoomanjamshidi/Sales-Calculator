<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Del extends InlineTag
{
}
