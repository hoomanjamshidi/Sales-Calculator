<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Details extends BlockTag
{
}
