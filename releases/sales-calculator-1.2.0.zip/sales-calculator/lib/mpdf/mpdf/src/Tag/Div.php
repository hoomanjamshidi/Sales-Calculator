<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Div extends BlockTag
{
}
