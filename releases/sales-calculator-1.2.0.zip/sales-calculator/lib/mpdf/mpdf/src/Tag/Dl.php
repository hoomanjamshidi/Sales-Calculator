<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Dl extends BlockTag
{
}
