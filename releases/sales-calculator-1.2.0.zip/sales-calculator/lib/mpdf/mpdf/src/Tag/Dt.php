<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Dt extends BlockTag
{
}
