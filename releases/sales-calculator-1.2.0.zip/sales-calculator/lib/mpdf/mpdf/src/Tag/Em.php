<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Em extends InlineTag
{
}
