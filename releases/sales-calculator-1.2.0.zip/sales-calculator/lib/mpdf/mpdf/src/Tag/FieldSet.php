<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class FieldSet extends BlockTag
{
}
