<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class FigCaption extends BlockTag
{
}
