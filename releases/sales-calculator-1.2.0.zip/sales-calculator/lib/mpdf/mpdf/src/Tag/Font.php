<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Font extends InlineTag
{
}
