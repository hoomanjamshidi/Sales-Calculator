<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Footer extends BlockTag
{
}
