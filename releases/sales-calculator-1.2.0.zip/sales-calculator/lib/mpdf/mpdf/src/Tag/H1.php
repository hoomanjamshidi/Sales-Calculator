<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class H1 extends BlockTag
{
}
