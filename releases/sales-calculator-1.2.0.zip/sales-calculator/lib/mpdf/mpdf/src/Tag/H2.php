<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class H2 extends BlockTag
{
}
