<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class H3 extends BlockTag
{
}
