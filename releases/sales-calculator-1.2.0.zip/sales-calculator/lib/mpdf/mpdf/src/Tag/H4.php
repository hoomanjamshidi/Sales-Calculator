<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class H4 extends BlockTag
{
}
