<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class H5 extends BlockTag
{
}
