<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class H6 extends BlockTag
{
}
