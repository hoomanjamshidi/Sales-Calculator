<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class HGroup extends BlockTag
{
}
