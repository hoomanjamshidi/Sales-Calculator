<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Header extends BlockTag
{
}
