<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class I extends InlineTag
{
}
