<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Ins extends InlineTag
{
}
