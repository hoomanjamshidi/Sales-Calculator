<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Kbd extends InlineTag
{
}
