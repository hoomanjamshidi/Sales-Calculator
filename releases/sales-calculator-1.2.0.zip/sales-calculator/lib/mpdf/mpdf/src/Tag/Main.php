<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Main extends BlockTag
{
}
