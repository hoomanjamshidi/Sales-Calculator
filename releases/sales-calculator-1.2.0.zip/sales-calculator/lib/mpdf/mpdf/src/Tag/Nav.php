<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Nav extends BlockTag
{
}
