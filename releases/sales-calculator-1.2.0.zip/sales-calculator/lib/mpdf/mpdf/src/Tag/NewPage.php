<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class NewPage extends FormFeed
{
}
