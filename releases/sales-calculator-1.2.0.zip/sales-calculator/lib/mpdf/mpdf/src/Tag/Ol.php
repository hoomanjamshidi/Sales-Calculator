<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Ol extends BlockTag
{
}
