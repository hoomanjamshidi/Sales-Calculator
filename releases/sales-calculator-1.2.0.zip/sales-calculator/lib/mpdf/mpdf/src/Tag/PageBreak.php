<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class PageBreak extends FormFeed
{
}
