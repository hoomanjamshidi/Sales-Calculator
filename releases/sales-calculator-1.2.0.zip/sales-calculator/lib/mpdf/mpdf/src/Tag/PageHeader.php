<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class PageHeader extends PageFooter
{
}
