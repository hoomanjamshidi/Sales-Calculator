<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Samp extends InlineTag
{
}
