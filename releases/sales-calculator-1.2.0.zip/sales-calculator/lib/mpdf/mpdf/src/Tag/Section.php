<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Section extends BlockTag
{
}
