<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class SetHtmlPageHeader extends SetHtmlPageFooter
{
}
