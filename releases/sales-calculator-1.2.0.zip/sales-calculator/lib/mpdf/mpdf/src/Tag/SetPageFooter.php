<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class SetPageFooter extends SetHtmlPageFooter
{
}
