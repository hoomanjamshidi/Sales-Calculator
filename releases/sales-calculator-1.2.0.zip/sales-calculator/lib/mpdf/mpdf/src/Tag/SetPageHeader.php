<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class SetPageHeader extends SetHtmlPageFooter
{
}
