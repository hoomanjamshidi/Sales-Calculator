<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Span extends InlineTag
{
}
