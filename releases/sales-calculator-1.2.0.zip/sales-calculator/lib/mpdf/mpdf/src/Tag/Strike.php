<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Strike extends InlineTag
{
}
