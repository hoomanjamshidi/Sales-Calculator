<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Strong extends InlineTag
{
}
