<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Sub extends InlineTag
{
}
