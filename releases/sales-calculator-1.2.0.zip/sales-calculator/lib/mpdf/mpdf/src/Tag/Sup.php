<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Sup extends InlineTag
{
}
