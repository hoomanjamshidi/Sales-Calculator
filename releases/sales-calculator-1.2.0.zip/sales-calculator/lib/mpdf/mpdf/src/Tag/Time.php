<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Time extends InlineTag
{
}
