<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class Tt extends InlineTag
{
}
