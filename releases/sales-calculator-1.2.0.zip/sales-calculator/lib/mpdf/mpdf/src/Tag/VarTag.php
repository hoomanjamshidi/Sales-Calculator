<?php

namespace SalesCalculatorVendor\Mpdf\Tag;

class VarTag extends InlineTag
{
}
