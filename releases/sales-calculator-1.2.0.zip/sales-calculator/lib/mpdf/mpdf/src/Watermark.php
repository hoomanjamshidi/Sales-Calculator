<?php

namespace SalesCalculatorVendor\Mpdf;

interface Watermark
{
}
