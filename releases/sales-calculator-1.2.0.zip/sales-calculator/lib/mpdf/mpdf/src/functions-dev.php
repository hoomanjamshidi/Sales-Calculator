<?php

namespace SalesCalculatorVendor;

if (!\function_exists('SalesCalculatorVendor\dd')) {
    function dd(...$args)
    {
        if (\function_exists('SalesCalculatorVendor\dump')) {
            dump(...$args);
        } else {
            \var_dump(...$args);
        }
        die;
    }
}
