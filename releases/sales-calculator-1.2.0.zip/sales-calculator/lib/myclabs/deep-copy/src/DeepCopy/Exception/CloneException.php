<?php

namespace SalesCalculatorVendor\DeepCopy\Exception;

use UnexpectedValueException;
class CloneException extends UnexpectedValueException
{
}
