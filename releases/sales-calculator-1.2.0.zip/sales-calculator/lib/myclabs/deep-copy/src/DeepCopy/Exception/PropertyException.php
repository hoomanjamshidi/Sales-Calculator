<?php

namespace SalesCalculatorVendor\DeepCopy\Exception;

use ReflectionException;
class PropertyException extends ReflectionException
{
}
