<?php

namespace SalesCalculatorVendor\DeepCopy\Matcher\Doctrine;

use SalesCalculatorVendor\DeepCopy\Matcher\Matcher;
use SalesCalculatorVendor\Doctrine\Persistence\Proxy;
/**
 * @final
 */
class DoctrineProxyMatcher implements Matcher
{
    /**
     * Matches a Doctrine Proxy class.
     *
     * {@inheritdoc}
     */
    public function matches($object, $property)
    {
        return $object instanceof Proxy;
    }
}
