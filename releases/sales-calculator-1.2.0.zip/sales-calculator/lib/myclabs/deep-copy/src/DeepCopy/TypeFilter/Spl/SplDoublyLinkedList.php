<?php

namespace SalesCalculatorVendor\DeepCopy\TypeFilter\Spl;

/**
 * @deprecated Use {@see SplDoublyLinkedListFilter} instead.
 */
class SplDoublyLinkedList extends SplDoublyLinkedListFilter
{
}
